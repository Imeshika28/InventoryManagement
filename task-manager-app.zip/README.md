# Task Manager Web App

## Description
A simple Laravel-based task manager app where users can register, log in, and manage tasks.

## Features
- User Authentication
- Create, View Tasks (CRUD)
- MySQL database integration
- Responsive design using Bootstrap

## Setup
1. Clone this repo.
2. Run `composer install`
3. Configure `.env` file and DB
4. Run `php artisan migrate`
5. Run `php artisan serve`
