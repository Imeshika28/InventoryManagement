<!DOCTYPE html>
<html>
<head>
    <title>My Tasks</title>
    <link rel="stylesheet" href="/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2>My Tasks</h2>
    <a href="{{ route('tasks.create') }}" class="btn btn-primary mb-3">Add Task</a>
    @foreach ($tasks as $task)
        <div class="card mb-2">
            <div class="card-body">
                <h5>{{ $task->title }}</h5>
                <p>{{ $task->description }}</p>
                <small>Due: {{ $task->due_date }}</small>
            </div>
        </div>
    @endforeach
</div>
</body>
</html>
